
paranoid_android = "Marvin"
letters = list(paranoid_android)
for char in letters:
    print('\t', char)

